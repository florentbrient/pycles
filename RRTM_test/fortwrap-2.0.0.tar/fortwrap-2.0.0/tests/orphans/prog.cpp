#include "FortWrap.h"

int main(void) 
{
  int x;
  x = FortFuncs::add(1,2);
  return 0;
}
